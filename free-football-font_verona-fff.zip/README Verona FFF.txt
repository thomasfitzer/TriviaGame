Verona FFF is based on the font used by Hellas Verona for the 2015/2016 season. You can 
visit Hellas Verona official website at http://www.hellasverona.it/

Verona FFF is a free font. However, the use of the font is limited to personal, private
and non-commercial purposes only. This means that the font (Verona FFF) should not be used
on items where you will directly or indirectly receive compensation in whatever form.

Verona FFF is brought to you by Mem�. Other fonts are available for download at 
http://freefootballfont.blogspot.com

Enjoy